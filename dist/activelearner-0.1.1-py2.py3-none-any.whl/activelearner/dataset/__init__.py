"""
Concrete dataset classes
"""
from .textdataset import TextDataset

__all__ = [
    'TextDataset'
]