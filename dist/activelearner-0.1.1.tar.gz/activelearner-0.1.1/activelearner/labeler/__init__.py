"""
Concrete labeler classes
"""
from .askoracle import AskOracle

__all__ = [
    'AskOracle'
]