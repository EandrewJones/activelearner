#!/usr/bin/env python

"""Tests for `activelearner` package."""


import unittest

from activelearner import activelearner


class TestActivelearner(unittest.TestCase):
    """Tests for `activelearner` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
