=============
ActiveLearner
=============


.. image:: https://img.shields.io/pypi/v/activelearner.svg
        :target: https://pypi.python.org/pypi/activelearner

.. image:: https://img.shields.io/travis/EandrewJones/activelearner.svg
        :target: https://travis-ci.com/EandrewJones/activelearner

.. image:: https://readthedocs.org/projects/activelearner/badge/?version=latest
        :target: https://activelearner.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Extensible Active Learning Framework


* Free software: Apache Software License 2.0
* Documentation: https://activelearner.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
