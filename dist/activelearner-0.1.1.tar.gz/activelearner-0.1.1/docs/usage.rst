=====
Usage
=====

To use ActiveLearner in a project::

    import activelearner
